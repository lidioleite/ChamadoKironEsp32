export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBvhzc7YhbmVHL6GPrOMLqkXwEzWDocKDI",
    authDomain: "kiron-921c2.firebaseapp.com",
    databaseURL: "https://kiron-921c2.firebaseio.com",
    projectId: "kiron-921c2",
    storageBucket: "kiron-921c2.appspot.com",
    messagingSenderId: "890458528422"
}
