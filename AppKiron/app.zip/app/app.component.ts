import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AngularFireDatabase } from 'angularfire2/database';
import { HomePage } from '../pages/home/home';
import { Storage } from '@ionic/storage';
import firebase from 'firebase';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;
  status;
  statusOrignal;
  yArray: any = [];

  testel: any;

  constructor(public storage: Storage, private db: AngularFireDatabase ,public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen) {
    this.initializeApp();
    this.status = firebase.database().ref('Leito_01');

    this.status.on('value', (snapshot) => {
      snapshot.forEach((childSnapshot) => {
        this.yArray.push(childSnapshot.val());
        this.statusOrignal = this.yArray.slice(-1);
          console.log('Teste: ' + this.statusOrignal);
      });
    });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
