import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';

import { TimelineComponent } from '../components/timeline/timeline';
import { TimelineTimeComponent } from '../components/timeline/timeline';
import { TimelineItemComponent } from '../components/timeline/timeline';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { CardIO } from '@ionic-native/card-io';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio'
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { MathematicalProvider } from '../providers/mathematical/mathematical';

import { InAppBrowser } from '@ionic-native/in-app-browser';
import { Camera } from '@ionic-native/camera';
import { NgProgressModule } from '@ngx-progressbar/core';


import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { FIREBASE_CONFIG } from './firebase.credentials';
import {IonicStorageModule} from '@ionic/storage';
import { StreamingMedia } from '@ionic-native/streaming-media';
import { CameraPipe } from '../pipes/camera/camera'

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    TimelineComponent,
    TimelineItemComponent,
    TimelineTimeComponent,
    CameraPipe
  ],
  imports: [
    BrowserModule,
  //  BrowserAnimationsModule,
    IonicModule.forRoot(MyApp),
    NgProgressModule.forRoot(),
    AngularFirestoreModule.enablePersistence(),
    AngularFireAuthModule,
    AngularFireModule.initializeApp(FIREBASE_CONFIG),
    AngularFireDatabaseModule,
    IonicStorageModule.forRoot()
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    TimelineComponent,
    TimelineItemComponent,
    TimelineTimeComponent,
  ],
  providers: [
    StatusBar,
    SplashScreen,
    CardIO,
    FingerprintAIO,
    File,
    FileOpener,
    InAppBrowser,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    MathematicalProvider,
    Camera,
    StreamingMedia
  ]
})
export class AppModule {}
